<?php
	ob_start();	
	require_once('bibli_generale.php');
	require_once('bibli_cuiteur.php');

	sc_bd_connexion();

	// Verification de la session active
	sc_session_verif();

	// Publication d'un nouveau blabla
	if (isset($_POST['btnPublier'])) {
		scl_publie();
	} 
	// recuitage d'un blabla
	if (isset($_GET['recuit'])) {
		scl_recuite();
	}
	// suppresion d'un blabla
	if (isset($_GET['delete'])) {
		scl_supprimer_blabla($_GET['delete']);
	}
	// gestion bonnement / désabonnement 
	if (isset($_POST['btnModifAbo'])) {
		scl_abonne();
	}
	// Plus de blablas
	if (isset($_GET['x'])) {
		list($IDUser, $limite) = explode('|', $_GET['x']);
	
		$limite = (int) $limite;
		if ($limite < 4) {
			sc_session_exit();			
		}

		$IDUser = (int) $IDUser;
		if ($IDUser != $_SESSION['usID']) {
			sc_session_exit();			
		}
		
		$_SESSION['nbBlabla'] = $limite;
	}


	//Rafraichissment de la page

	if (! isset($_GET['reply'])) 
	{
		$replyTo = '';
	}
	else 
	{
		$replyTo = htmlentities("@{$replyTo}");
	}
	
	$txt = "<form id='frmPublier' action='cuiteur.php' method='POST'>
			<textarea id='txtMessage' name='txtMessage' focus='yes'>{$replyTo}</textarea>
			<input id='btnPublier' type='submit' name='btnPublier' value='' title='Publier mon blabla'>
			</form>".
			'<div> grade : '.$_SESSION['auth_type'].' </div>';
				
	sc_aff_html_debut('Cuiteur | Accueil'); 
		 
	sc_aff_entete($txt);
	
	sc_aff_infos();
	
	sc_aff_blablas(1, $_SESSION['usID'], $_SESSION['nbBlabla']);
		
	sc_aff_pied();

	mysql_close();
	ob_end_flush();
//--------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------
	/**
	* Traitement de la publication d'un message
	*/
	function scl_publie() {
		$msg = sc_bd_proteger(trim($_POST['txtMessage']));
		
		$dest = (substr($msg, 0, 1) == '@') ? 1 : 0;
		$date = date('Ymd');
		$heure = date('H:i:s');
		
		$sql = "INSERT 
				INTO	blablas
				SET 	blIDAuteur='{$_SESSION['usID']}', 
						blTexte = '{$msg}', 
						blAvecCible = {$dest}, 
						blDate = {$date},
						blHeure = '{$heure}',
						blIDOriginal = 0";
		mysql_query($sql) or sc_bd_erreur($sql);			           	   
		
		$blID = mysql_insert_id();
		
		scl_insert_mentions($msg, $blID);			
		scl_insert_tags($msg, $blID);
	}

	/**
	* Traitement du recuitage d'un message : le message est copié
	*/
	function scl_recuite() {
		$meRecuit = (int) $_GET['recuit'];
		if ($meRecuit < 1) {
			sc_session_exit();			
		}
		
		$sql = "SELECT	*
				FROM	blablas
				WHERE	blID = {$meRecuit}";
		$res = mysql_query($sql) or sc_bd_erreur($sql);
		
		if (mysql_num_rows($res) == 0) {
			return;
		}	
		
		$t = mysql_fetch_assoc($res);
		
		$date = date('Ymd');
		$heure = date('H:i:s');
		$txt = sc_bd_proteger($t['blTexte']);
		
		$sql = "INSERT 
				INTO	blablas 
				SET		blIDAuteur={$_SESSION['usID']}, 
						blAvecCible = {$t['blAvecCible']}, 
						blTexte = '{$txt}', 
						blDate = {$date},
						blHeure = '{$heure}',
						blIDOriginal = {$t['blIDAuteur']}";
		mysql_query($sql) or sc_bd_erreur($sql);
		
		$blID = mysql_insert_id();

		scl_insert_tags($txt, $blID);
		scl_insert_mentions($txt, $blID);
	}

	/**
	* Traitement des réferences aux utilisateurs inclus 
	* dans le message 
	*
	* @param string		$msg	Le texte du message à analyser
	* @param integer	$blID	identifiant du message
	*/
	function scl_insert_mentions($msg,  $blID) {
		// extraction des pseudos cités dans le blabla
		preg_match_all('~@[\d|\p{L}]{4,20}~', $msg, $users);
			
		// recherche des destinataires
		if (count($users) == 0 || count($users[0] == 0))
        {
            return;
        }
        
        // On tranforme le tableau en chaîne de pseudos separés par des virgules
        // On entoure les pseudos avec des guillemets
        $sql = implode(',', $pseudos[0]);
        $sql = str_replace(array('@', ','), array("'", "',"), $sql);
        $sql .= "'";
	    $sql = "SELECT	*
                FROM	users
                WHERE 	usID IN ({$sql})";	    
		$res = mysql_query($sql) or sc_bd_erreur($sql);
		
        $sql = '';
		while ($t = mysql_fetch_assoc($res)) {
			$sql .= ",({$t['usID']}, {$blID})";
		}
		
		$sql = substr($sql, 1);		
		if ($sql != '') {
			$sql = "INSERT 
					INTO	mentions (meIDUser, meIDBlabla)
                    VALUES	{$sql}";
            $res = mysql_query($sql) or sc_bd_erreur($sql);
        }
	}

	/**
	* Traitement des tags inclus dans le message : ajout dans la base
	*
	* @param string		$msg	Le texte du message à analyser
	* @param integer	$blID	identifiant du message  
	*/
	function scl_insert_tags($msg, $blID) {
		// extraction des tags 
		preg_match_all('~#[\d|\p{L}|_]*~', $msg, $tags);
						
		// ajout des tags
		if (count($tags) == 0 || count($tags[0]) == 0)
		{
		    return;
  		}
  		
  		$sql = '';
		foreach	($tags[0] as $zeTag) {
			$tag = substr($zeTag, 1);
			$sql .= ",('{$tag}', {$blID})";
		}
		
		$sql = substr($sql, 1);
		if ($sql != '') {		
			$sql = "INSERT 
					INTO	tags	
					VALUES	$sql";		        
			$res=mysql_query($sql) or sc_bd_erreur($sql);
		}
	}

	/**
	* Validation des abonnements, désabonnements.
	*/
	function scl_abonne() {
		$delete = $insert = '';
		$jour = date('Ymd');

		foreach ($_POST as $cle => $val) 
		{
			$prefixe = substr($cle, 0, 7);
			if ($prefixe == 'frmAbo_') 
			{
				$ID = sc_decrypter($val);
				$insert .= ", ({$_SESSION['usID']}, {$ID}, {$jour})";
			}
			if ($prefixe == 'frmDes_') 
			{
				$ID = sc_decrypter($val);
				$delete .= ", {$ID}";
			}
		}

		// Insert des nouveaux abonnements
		$insert = substr($insert, 1); // enlève la virgule
		if ($insert != '') {
			$sql = "INSERT 
					INTO	estabonne	(eaIDUser, eaIDAbonne, eaDate)
                    VALUES	$insert";
			$res=mysql_query($sql) or sc_bd_erreur($sql);		                    
		}
		
		//suppression des abonnements
		$delete = substr($delete, 1); // enlève la virgule
		if ($delete != '') {
			$sql = "DELETE
					FROM	estabonne
					WHERE	eaIDUser = {$_SESSION['usID']}
					AND		eaIDAbonne IN ({$delete})";	
			$res=mysql_query($sql) or sc_bd_erreur($sql);		                    						
		}	
	}
?>