<?php	
	require_once('bibli_generale.php');
	require_once('bibli_cuiteur.php');
	ob_start();

	if (isset($_POST['btnValider'])) {
		$erreurs = scl_inscription_utilisateur();
	} else {
		$erreurs = array();
	}

	$txt = '<h1>Inscription</h1>
			<p id="bcDescription">Pour vous inscrire il suffit de : </p>';
		
	sc_html_debut('Cuiteur | Inscription','../styles/cuiteur.css');	

	sc_aff_entete($txt, FALSE);	

	sc_aff_infos(false);
	echo '<div id="bcContenu">';
	
	if (count($erreurs) > 0) {
		echo '<div class="form_error">Veuillez corriger les erreurs suivantes : <br>';
		foreach ($erreurs as $err_msg) {
			echo '&nbsp; &nbsp; - ', htmlentities($err_msg), '<br>';
		}
		echo '</div>';
	}
	
	$pseudo = (isset($_POST['pseudo'])) ? $_POST['pseudo'] : '';
	$nom = (isset($_POST['nom'])) ? $_POST['nom'] : '';
	$email = (isset($_POST['email'])) ? $_POST['email'] : '';
	
	echo '<form action="inscription.php" method="post">',
			'<table width="500" border="0">',
			sc_form_ligne('Choisir un pseudo', sc_form_input('text', 'pseudo', $pseudo, 20)),
			sc_form_ligne('Choisir un mot de passe', sc_form_input('password', 'password1', '', 20)),
			sc_form_ligne('R&eacute;p&eacute;ter le mot de passe', sc_form_input('password', 'password2', '', 20)),			
			sc_form_ligne('Indiquer votre nom',  sc_form_input('text', 'nom', $nom, 35)),
			sc_form_ligne('Donner une adresse email', sc_form_input('text', 'email', $email, 35)),
			sc_form_ligne(sc_form_input('submit', 'btnValider', 'Je m\'inscris')),									 
			'</table>',
		'</form>',
	'</div>';

	sc_aff_pied();
	ob_end_flush();
	
	
	/**
	* Traitement du formulaire d'inscription.
	* Vérification et mise à jour de la base de données
	* 
	* @return array Tableau des erreurs 
	*/
	function scl_inscription_utilisateur() {

		//Vérification dans la base de données
		$erreurs = array();
		sc_bd_connexion();
		$_POST['pseudo'] = trim($_POST['pseudo']);
		$len=strlen($_POST['pseudo']);
		if (($len<4)||($len>31)) {
			$erreurs[] = 'Votre pseudo doit être composés de 4 à 30 
						caractères alphanumériques, sans espaces ni ponctuation.';				
		}
		else {
			
			$sql = 'SELECT	*
					FROM	users
					WHERE	usPseudo = "'.sc_bd_proteger($_POST['pseudo']).'"';
			$res = mysql_query($sql) or sc_bd_erreur($sql);
			if (mysql_num_rows($res) != 0) {
				$erreurs[] = 'Ce pseudo est réservé. Choisissez-en un autre.';
			}
			mysql_free_result($res);
		}
		
		$_POST['nom'] = trim($_POST['nom']);
		if ($_POST['nom'] == '') {
			$erreurs[] = 'Votre nom doit être renseigné.';
		}
		
		$_POST['email'] = trim($_POST['email']);		
		if ($_POST['email'] == '') {
			$erreurs[] = 'Votre adresse email doit être renseignée.';
		}
		else {
			if (! sc_ok_mail($_POST['email'])) {
				$erreurs[] = 'Votre adresse email n\'est pas valide.';
			}
		}	
		
		$_POST['password1'] = trim($_POST['password1']);
		$_POST['password2'] = trim($_POST['password2']);
		if ($_POST['password1'] == ''
		|| $_POST['password2'] == '')
		{
			$erreurs[] = 'Les mots de passe doivent être renseignés.';
		}
		else {
			if ($_POST['password1'] !== $_POST['password2']) {
				$erreurs[] = 'Les mots de passe doivent être identiques.';
			}
		}
		
		if (count($erreurs) != 0) {
		    return $erreurs;
  		}

		// enregistrement dans la base de données
		$pseudo = $_POST['pseudo'];
		$_POST['pseudo'] = sc_bd_proteger($_POST['pseudo']);
		$_POST['nom'] = sc_bd_proteger($_POST['nom']);
		$_POST['email'] = $_POST['email'];
		$_POST['password1'] = sc_bd_proteger(md5($_POST['password1']));
		$dateInscription = date('Ymd');
		
		$sql = "INSERT INTO users SET
				usPseudo = '{$_POST['pseudo']}',
				usNom = '{$_POST['nom']}',
				usMail = '{$_POST['email']}',
				usPasse = '{$_POST['password1']}',
				usDateInscription = {$dateInscription},
				usBio = '',
				usDateNaissance = 0,
				usAvecPhoto=0";
		mysql_query($sql) or sc_bd_erreur($sql);

		$usID =  mysql_insert_id();
		mysql_close();
		sc_session_start($pseudo, $usID, $_POST['nom'], 0);
	}
?>
