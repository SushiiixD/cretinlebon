#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int pid;
	int i=3;
	int sig=atoi(argv[2]); //SIGNAL THAT SHOULD BE SENT TO ALL THE PROCESSES SPECIFIED BY pid
	if(strcmp(argv[1],"-s"))
	{
		fprintf(stderr,"ERROR! -s needed!\n");
		exit(EXIT_FAILURE);
	}
	while(argv[i]!=NULL)
	{
		pid=atoi(argv[i]);
		kill(pid,sig);
		i++;
	}
	exit(EXIT_SUCCESS);
}