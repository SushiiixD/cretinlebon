#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int system(const char *command)
{
	int cdr;
	char *com[] = {"", "-c",command, NULL }; 
	/*option -c, nom de la commande en paramètre, NULL représente la fin, le tout sous forme d'un tableau */
	cdr = execv("/bin/sh",com); 
	/*Chemin de l'exécutable,  et le tableau de la commande précédent */
	return cdr;
}

int main(int argc, char *argv[])
{
	printf("%d\n",system(argv[1]));
	exit(EXIT_SUCCESS);
}