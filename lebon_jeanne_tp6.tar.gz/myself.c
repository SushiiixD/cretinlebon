#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	FILE *fp;
	fp=fopen("myself.pid","w");
	pid_t pid=getpid();
	if(pid<0) 
	{
		fprintf(stderr,"Can't find pid");
		fclose(fp);
		exit(EXIT_FAILURE);
	}
	printf("The PID is %d. \n",pid);
	fclose(fp);
	exit(EXIT_SUCCESS);
}