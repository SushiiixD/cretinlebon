#include <stdio.h>
#include <stdlib.h>
#include <time.h> 
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/wait.h>

//Exercice 16
// 16.1
int main(int argc, char *argv[])
{
	int status;
	struct timeval begin,end;
	gettimeofday(&begin,NULL);
	pid_t pid=fork();
	if(pid<0)
	{
		exit(EXIT_FAILURE);
	}
//16.2	
	if(pid==0)
	{
		execvp(argv[1],&argv[1]);
		exit(EXIT_FAILURE);
	}
	int ret=wait(&status);
	if(ret==-1)
	{
		perror("wait");
	}
	wait(&status);
	if(WIFEXITED(status)==1)
	{
		fprintf(stdout, "The process ended normally.\n%d \n",WEXITSTATUS(status));
	}
	if(WIFSIGNALED(status)==1)
	{
		fprintf(stdout, "The process ended because of the signal's reception.\n%d \n",WTERMSIG(status));
	}
//16.3
	gettimeofday(&end,NULL);
	long t=(end.tv_sec - begin.tv_sec)*1000000+(end.tv_usec - begin.tv_usec);
	printf("Time: %ld \n",t);
	return EXIT_SUCCESS;
}